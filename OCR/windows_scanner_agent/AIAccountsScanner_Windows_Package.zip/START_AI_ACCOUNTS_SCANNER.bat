@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\AIAccountsScanner\RUN_AI_ACCOUNTS_SCANNER_AGENT.ps1
echo AI-Accounts scanner agent start command sent.
pause
